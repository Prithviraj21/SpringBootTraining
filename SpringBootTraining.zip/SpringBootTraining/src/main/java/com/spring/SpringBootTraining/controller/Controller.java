package com.spring.SpringBootTraining.controller;

import com.spring.SpringBootTraining.dto.EmployeeDto;
import com.spring.SpringBootTraining.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class Controller {
    @Autowired
    private EmpService service;

    @PostMapping("/addEmployee")
    public EmployeeDto saveEmployee(@RequestBody EmployeeDto dto){
        EmployeeDto employeeDto=service.addEmployee(dto);
        return employeeDto;
    }


    @GetMapping("/findByemployeeName{employeeName}")
    public EmployeeDto findByemployeeName(@RequestBody EmployeeDto dto){
        EmployeeDto employeeDto=service.findByemployeeName(dto.getEmployeeName());
        return employeeDto;
    }

    @DeleteMapping("/deleteEmployee")
    public String deleteEmployee(@RequestBody EmployeeDto dto){
        String string = dto.getEmployeeName()+" Deleted Succefully";
        service.deleteEmployee(dto);
        return string;
    }

    @PutMapping("/updateEmployee")
    public EmployeeDto updateEmployee(@RequestBody EmployeeDto dto){
        EmployeeDto dto1=service.updateEmployee(dto);


    return dto1;
    }


}
