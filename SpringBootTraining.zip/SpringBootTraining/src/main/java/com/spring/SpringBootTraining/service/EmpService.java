package com.spring.SpringBootTraining.service;

import com.spring.SpringBootTraining.dao.EmployeeDao;
import com.spring.SpringBootTraining.dto.EmployeeDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.stereotype.Service;

@Service
public class EmpService implements EmployeeService{
    @Autowired
    private EmployeeDao dao;
    @Override
    public EmployeeDto addEmployee(EmployeeDto dto) {
        return dao.save(dto);
    }

    @Override
    public EmployeeDto findByemployeeName(String employeeName) {
        return dao.findByemployeeName(employeeName);
    }

    @Override
    public void deleteEmployee(EmployeeDto dto) {
        dao.deleteById(dto.getEmployeeId());
    }

    @Override
    public EmployeeDto updateEmployee(EmployeeDto dto) {
        return dao.save(dto) ;
    }
}
