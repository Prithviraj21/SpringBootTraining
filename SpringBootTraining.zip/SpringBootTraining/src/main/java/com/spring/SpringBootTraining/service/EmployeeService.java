package com.spring.SpringBootTraining.service;

import com.spring.SpringBootTraining.dto.EmployeeDto;

public interface EmployeeService {
    EmployeeDto addEmployee(EmployeeDto dto);
    EmployeeDto findByemployeeName(String employeeName);

    void deleteEmployee(EmployeeDto dto);

    EmployeeDto updateEmployee(EmployeeDto employeeDto);
}
