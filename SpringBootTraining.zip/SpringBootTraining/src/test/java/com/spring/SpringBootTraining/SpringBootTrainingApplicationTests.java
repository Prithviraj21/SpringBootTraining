package com.spring.SpringBootTraining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTrainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
